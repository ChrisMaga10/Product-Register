CREATE PROCEDURE SP_MostrarProducto
AS
SELECT cod_prod, nombre, existencia, imagen  FROM productos
GO

CREATE PROCEDURE SP_RegistrarProducto
@CodProd varchar(4),
@Nombre varchar(50),
@Existencia int,
@Imagen image
AS
begin
insert into productos  values(@CodProd, @Nombre, @Existencia, @imagen)
end
GO

CREATE PROCEDURE SP_ModificarProducto
@CodProd varchar(4), 
@Nombre varchar(50), 
@Existencia int,
@Imagen image
AS
update productos  set cod_prod =@CodProd, nombre=@Nombre, existencia=@Existencia, imagen=@Imagen
where
cod_prod=@CodProd
GO

CREATE PROC SP_EliminarProducto
@CodProd as varchar(4)
AS
delete from productos WHERE cod_prod=@CodProd 
