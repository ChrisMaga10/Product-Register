﻿Imports System.Data.SqlClient
Public Class Form1
    Dim reg As New Propiedades
    Dim func As New Funciones

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        DataGridView1.DataSource = func.Mostrar_Producto
        Mostrar()

    End Sub
    Private Sub Mostrar()
        DataGridView1.Visible = True
        DataGridView1.Columns(3).Visible = False
        Label1.Visible = False
        Label2.Visible = False
        Label3.Visible = False
        Label4.Visible = True
        Label5.Visible = True
        Label6.Visible = True

        TextBox1.Visible = False
        TextBox1.Enabled = True
        TextBox2.Visible = False
        TextBox3.Visible = False

        btn_Cancelar.Visible = False
        btn_Modificar.Visible = True
        btn_Nuevo.Visible = True
        btn_Guardar.Visible = True
        btn_Eliminar.Visible = True

        btn_Insertar.Visible = False
        btn_Quitar.Visible = False
    End Sub
    Private Sub DataGridView1_CellClick(sender As Object, e As DataGridViewCellEventArgs) Handles DataGridView1.CellClick
        TextBox1.Text = DataGridView1.SelectedCells.Item(0).Value
        TextBox2.Text = DataGridView1.SelectedCells.Item(1).Value
        TextBox3.Text = DataGridView1.SelectedCells.Item(2).Value

        imagen.BackgroundImage = Nothing
        Dim i() As Byte = DataGridView1.SelectedCells.Item(3).Value
        Dim ms As New IO.MemoryStream(i)
        imagen.Image = Image.FromStream(ms)
        imagen.SizeMode = PictureBoxSizeMode.StretchImage

    End Sub

    Private Sub DataGridView1_CellPainting(sender As Object, e As DataGridViewCellPaintingEventArgs) Handles DataGridView1.CellPainting
        If DataGridView1.Rows.Count = 0 Then
            TextBox1.Text = ""
            TextBox2.Text = ""
            TextBox3.Text = ""
            Exit Sub
        Else
            TextBox1.Text = DataGridView1.SelectedCells.Item(0).Value
            TextBox2.Text = DataGridView1.SelectedCells.Item(1).Value
            TextBox3.Text = DataGridView1.SelectedCells.Item(2).Value

            imagen.BackgroundImage = Nothing
            Dim i() As Byte = DataGridView1.SelectedCells.Item(3).Value
            Dim ms As New IO.MemoryStream(i)
            imagen.Image = Image.FromStream(ms)
            imagen.SizeMode = PictureBoxSizeMode.StretchImage
        End If
    End Sub
    Private Sub btn_Nuevo_Click(sender As Object, e As EventArgs) Handles btn_Nuevo.Click
        DataGridView1.Visible = False
        imagen.Image = My.Resources.SIN_FOTO

        Label1.Visible = True
        Label2.Visible = True
        Label3.Visible = True
        Label4.Visible = False
        Label5.Visible = False
        Label6.Visible = False

        TextBox1.Visible = True
        TextBox2.Visible = True
        TextBox3.Visible = True
        TextBox1.Text = ""
        TextBox2.Text = ""
        TextBox3.Text = ""

        btn_Nuevo.Visible = False
        btn_Registrar.Visible = True
        btn_Modificar.Visible = False
        btn_Guardar.Visible = False
        btn_Eliminar.Visible = False
        btn_Cancelar.Visible = True

        btn_Insertar.Visible = True
        btn_Quitar.Visible = True

        TextBox1.Focus()
    End Sub
    Private Sub btn_Registrar_Click(sender As Object, e As EventArgs) Handles btn_Registrar.Click
        If Me.ValidateChildren = True And TextBox1.Text <> "" And TextBox2.Text <> "" And TextBox3.Text <> "" Then
            Try
                reg.cod_prod = TextBox1.Text
                reg.nombre = TextBox2.Text
                reg.existencia = TextBox3.Text


                Dim ms As New IO.MemoryStream()

                If Not imagen.Image Is Nothing Then
                    imagen.Image.Save(ms, imagen.Image.RawFormat)
                Else
                    imagen.Image = My.Resources.SIN_FOTO
                    imagen.Image.Save(ms, imagen.Image.RawFormat)
                End If
                reg.imagen = ms.GetBuffer



                If func.Registrar_Producto(reg) Then
                    MessageBox.Show("Producto Guardado correctamente", "Guardando Producto")
                    DataGridView1.DataSource = func.Mostrar_Producto
                    Mostrar()
                End If

            Catch ex As Exception
                MsgBox(ex.Message)
            End Try
        Else
            MessageBox.Show("Debe rellenar todos los campos", "Guardando Producto", MessageBoxButtons.OK, MessageBoxIcon.Information)

        End If
    End Sub
    Private Sub btn_Modificar_Click(sender As Object, e As EventArgs) Handles btn_Modificar.Click
        If DataGridView1.Rows.Count = 0 Then
            MessageBox.Show("La tabla está vacía", "Modificando Producto", MessageBoxButtons.OK, MessageBoxIcon.Information)
            Exit Sub
        End If

        DataGridView1.Visible = False
        Label1.Visible = True
        Label2.Visible = True
        Label3.Visible = True
        Label4.Visible = False
        Label5.Visible = False
        Label6.Visible = False

        TextBox1.Visible = True
        TextBox1.Enabled = False
        TextBox2.Visible = True
        TextBox2.Focus()
        TextBox3.Visible = True

        btn_Nuevo.Visible = False
        btn_Registrar.Visible = False
        btn_Modificar.Visible = False
        btn_Eliminar.Visible = False
        btn_Cancelar.Visible = True

        btn_Insertar.Visible = True
        btn_Quitar.Visible = True
    End Sub
    Private Sub btn_Guardar_Click(sender As Object, e As EventArgs) Handles btn_Guardar.Click
        If Me.ValidateChildren = True And TextBox1.Text <> "" And TextBox2.Text <> "" And TextBox3.Text <> "" Then
            Try
                reg.cod_prod = TextBox1.Text
                reg.nombre = TextBox2.Text
                reg.existencia = TextBox3.Text

                Dim ms As New IO.MemoryStream()

                If Not imagen.Image Is Nothing Then
                    imagen.Image.Save(ms, imagen.Image.RawFormat)
                Else
                    imagen.Image = My.Resources.SIN_FOTO
                    imagen.Image.Save(ms, imagen.Image.RawFormat)
                End If
                reg.imagen = ms.GetBuffer


                If func.Modificar_Producto(reg) Then
                    MessageBox.Show("Producto Modificado correctamente", "Modificando Producto")
                    DataGridView1.DataSource = func.Mostrar_Producto
                    Mostrar()
                End If

            Catch ex As Exception
                MsgBox(ex.Message)
            End Try
        Else
            MessageBox.Show("Debe rellenar todos los campos", "Modificando Producto", MessageBoxButtons.OK, MessageBoxIcon.Information)

        End If
        
    End Sub
    Private Sub btn_Eliminar_Click(sender As Object, e As EventArgs) Handles btn_Eliminar.Click
        Dim result As DialogResult

        If DataGridView1.Rows.Count = 0 Then
            MessageBox.Show("La tabla está vacía", "Eliminando Producto", MessageBoxButtons.OK, MessageBoxIcon.Information)
            Exit Sub
        End If

        result = MessageBox.Show("¿Seguro que desea eliminar este producto?", "Eliminando Producto", MessageBoxButtons.YesNo, MessageBoxIcon.Question)

        If result = DialogResult.Yes Then
            If Me.ValidateChildren = True And TextBox1.Text <> "" Then

                Try
                    reg.cod_prod = TextBox1.Text

                    If func.Eliminar_Producto(reg) Then
                        MessageBox.Show("Producto eliminadoo correctamente", "Eliminando Producto")
                        DataGridView1.DataSource = func.Mostrar_Producto

                        If DataGridView1.Rows.Count = 0 Then
                            TextBox1.Text = ""
                            TextBox2.Text = ""
                            TextBox3.Text = ""
                            imagen.Image = My.Resources.SIN_FOTO
                        End If
                    Else
                        MessageBox.Show("Producto no encontrado", "Eliminando Producto", MessageBoxButtons.OK, MessageBoxIcon.Information)

                    End If

                Catch ex As Exception
                    MsgBox(ex.Message)
                End Try
            End If
          End If
    End Sub
    Private Sub btn_Cancelar_Click(sender As Object, e As EventArgs) Handles btn_Cancelar.Click
        Mostrar()
    End Sub

    Private Sub btn_Insertar_Click(sender As Object, e As EventArgs) Handles btn_Insertar.Click
        If dlgBox.ShowDialog() = DialogResult.OK Then
            imagen.BackgroundImage = Nothing
            imagen.Image = New Bitmap(dlgBox.FileName)
            imagen.SizeMode = PictureBoxSizeMode.StretchImage
        End If
    End Sub

    Private Sub btn_Quitar_Click(sender As Object, e As EventArgs) Handles btn_Quitar.Click
        imagen.Image = Nothing
        imagen.BackgroundImage = My.Resources.SIN_FOTO
        imagen.SizeMode = PictureBoxSizeMode.StretchImage
    End Sub

    Private Sub TextBox1_KeyPress(sender As Object, e As KeyPressEventArgs) Handles TextBox1.KeyPress
        If e.KeyChar = ChrW(Keys.Enter) Then
            e.Handled = True
            SendKeys.Send("{TAB}")
        End If
    End Sub

    Private Sub TextBox2_KeyPress(sender As Object, e As KeyPressEventArgs) Handles TextBox2.KeyPress
        If e.KeyChar = ChrW(Keys.Enter) Then
            e.Handled = True
            SendKeys.Send("{TAB}")
        End If
    End Sub
    Private Sub TextBox3_KeyPress(sender As Object, e As KeyPressEventArgs) Handles TextBox3.KeyPress
        If Char.IsDigit(e.KeyChar) Then
            e.Handled = False
        ElseIf Char.IsControl(e.KeyChar) Then
            e.Handled = False
        Else
            e.Handled = True
        End If
    End Sub

End Class