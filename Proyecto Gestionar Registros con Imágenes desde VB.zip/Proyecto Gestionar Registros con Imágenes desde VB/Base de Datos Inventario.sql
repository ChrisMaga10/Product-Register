create database inventario;
GO
use inventario;
GO
create table productos
(
id_Cod int identity primary key,
cod_prod varchar(4) not null,
nombre varchar(50)not null,
existencia int not null,
imagen image
)